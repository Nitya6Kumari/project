package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class UpdateServlet extends HttpServlet 
{
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String name = request.getParameter("empname");
		String id = request.getParameter("eid");
		String sal = request.getParameter("salary");
	    try
	    {
	    	Class.forName("oracle.jdbc.driver.OracleDriver");
	    	String url = "jdbc:oracle:thin:@localhost:1521:XE";
	    	String user = "hr";
	    	String pass = "hr";
	    	Connection con = DriverManager.getConnection(url, user, pass);
	    	String sql = "update employee set ename=? , esal=? where id=?";
	    	PreparedStatement ps = con.prepareStatement(sql);
	    	
	    	ps.setString(1, name);
	    	ps.setDouble(2, Double.parseDouble(sal));
	    	ps.setInt(3, Integer.parseInt(id));
	    	int n = ps.executeUpdate();
	    	if(n>=1)
	    	{
	    		out.println("Updated!!!!!!!!");
	    		RequestDispatcher rd = request.getRequestDispatcher("viewEmployees.jsp");
	    		rd.forward(request, response);
	    	}
	    	else
	    	{
	    		RequestDispatcher rd = request.getRequestDispatcher("updateEmployee.jsp");
	    		rd.forward(request, response);
	    	}
	    	
	    }
	    catch(Exception e)
	    {
	    	out.println(e);
	    }
		
		
	}

}
