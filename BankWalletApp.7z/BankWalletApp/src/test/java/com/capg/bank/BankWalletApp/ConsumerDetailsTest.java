package com.capg.bank.BankWalletApp;

import junit.framework.TestCase;

public class ConsumerDetailsTest extends TestCase {

	public void testGetConsumerName() {
		fail("Not yet implemented");
	}

	public void testGetAge() {
		fail("Not yet implemented");
	}

	public void testGetGender() {
		fail("Not yet implemented");
	}

	public void testGetEmailId() {
		fail("Not yet implemented");
	}

	public void testGetPhoneNo() {
		fail("Not yet implemented");
	}

	public void testGetUserName() {
		fail("Not yet implemented");
	}

	public void testGetPassword() {
		fail("Not yet implemented");
	}

}
