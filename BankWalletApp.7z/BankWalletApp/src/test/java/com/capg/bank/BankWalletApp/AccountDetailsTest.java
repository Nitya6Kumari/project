package com.capg.bank.BankWalletApp;

import static org.junit.Assert.assertNotSame;

import junit.framework.TestCase;

public class AccountDetailsTest extends TestCase {

	public void testGetConsumerDetails() {
		//fail("Not yet implemented");
	}

	public void testGetUserName() {
		//fail("Not yet implemented");
	}

	public void testGetPassword() {
		//fail("Not yet implemented");
	}

	public void testGetTransactionId() {
		//fail("Not yet implemented");
		assertNotSame(500,0);
		assertNotSame(200,0);
	}

	public void testGetSenderAccount() {
		//fail("Not yet implemented");
	}

	public void testGetReceiverAccount() {
		//fail("Not yet implemented");
	}

	public void testGetBalance() {
		//fail("Not yet implemented");
	}

	public void testGetAmount() {
		//fail("Not yet implemented");
	}

}
