package com.cg.servlet.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginDAO implements ILoginDAO 
{

	public Connection con = null;
	public Connection getConnection()
	{
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin@localhost:1521:XE";
			String user = "hr";
			String pass = "hr";
			con = DriverManager.getConnection(url, user, pass);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return con;
	}
	
	@Override
	public String validateuser(String username, String pass) 
	{
		con = getConnection();
		String sql = "select name from Enduser where password=?";
		try
		{
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, pass);
			ResultSet rs = ps.executeQuery();
			if(rs.next())
			{
				return rs.getString(2);
			}
		}catch(Exception e)
		{
			System.err.println("Check your query");
		}
		return null;
	}
	

}
