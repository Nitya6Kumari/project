package com.cg.servlet.dao;

public interface ILoginDAO 
{
	public String validateuser(String username, String pass);

}
