package com.cg.servlet.service;

import com.cg.servlet.dao.LoginDAO;

public class LoginService implements Iloginservice
{

	LoginDAO dao = new LoginDAO();
	@Override
	public String validateuser(String username, String pass) 
	
	{
		return dao.validateuser(username, pass);
		
	}
	

}
