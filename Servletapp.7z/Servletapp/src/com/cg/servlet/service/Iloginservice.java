package com.cg.servlet.service;

public interface Iloginservice 
{
	public String validateuser(String username, String pass);

}
