package com.cg.servlet.controller;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.servlet.service.LoginService;

/**
 * Servlet implementation class LoginServlet_P3
 */
@WebServlet("/LoginServlet_P3")
public class LoginServlet_P3 extends HttpServlet 
{
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter ou = response.getWriter();
		String name=request.getParameter("name");
		String passname = request.getParameter("password");
		LoginService l = new LoginService();
		String user= l.validateuser(name, passname);
		if(user.equals(name))
		{
		System.out.println("hello" +name);
		}
		else
			System.out.println("Login again");
		
	}

	
}
